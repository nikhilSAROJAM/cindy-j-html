var $zero = $(".main_cont");
var $one = $(".one");
var $two = $(".two");
var $three = $(".three");
var $four = $(".four");
var $five = $(".five");
var y;
var winners =
{
  queue:
  []
};

function ans(x) {

  switch (x) {
    case 0:
      var tl0 = new TimelineMax();
      tl0.to($zero, .5, {x:"100%", ease: Power1.easeIn})
         .to($one, .5, {x:"-100%", ease: Power1.easeOut});

      $(".tzero").removeClass("active");
      $(".tone").addClass("active");

      break;

    case 1:

      y = $("#ans1").val();
      y = y.toLowerCase();

      if (y == "peace") {
        var tl1 = new TimelineMax();
        tl1.to($one, .5, {x:"100%", ease: Power1.easeIn})
           .to($two, .5, {x:"-100%", ease: Power1.easeOut});

        $(".tone").removeClass("active");
        $(".ttwo").addClass("active");
      }

      break;

    case 2:

      y = $("#ans2").val();
      y = y.toLowerCase();

      if (y == "love") {
        var tl2 = new TimelineMax();
        tl2.to($two, .5, {x:"100%", ease: Power1.easeIn})
           .to($three, .5, {x:"-100%", ease: Power1.easeOut});

        $(".ttwo").removeClass("active");
        $(".tthree").addClass("active");
      }

      break;

    case 3:

      y = $("#ans3").val();
      y = y.toLowerCase();

      if (y == "unity") {
        var tl3 = new TimelineMax();
        tl3.to($three, .5, {x:"100%", ease: Power1.easeIn})
           .to($four, .5, {x:"-100%", ease: Power1.easeOut});

        $(".tthree").removeClass("active");
        $(".tfour").addClass("active");
      }

      break;

    case 4:

      y = $("#ans4").val();
      y = y.toLowerCase();

      if (y == "respect") {
        var tl4 = new TimelineMax();
        tl4.to($four, .5, {x:"100%", ease: Power1.easeIn})
           .to($five, .5, {x:"-100%", ease: Power1.easeOut});

        $(".tfour").removeClass("active");
        $(".tfive").addClass("active");
      }

      break;

    case 5:

      y = $("#ans5").val();
      y = y.toLowerCase();

      if (y != null) {
        var tl4 = new TimelineMax();
        tl4.to($five, .5, {x:"100%", ease: Power1.easeIn})
           .to($six, .5, {x:"-100%", ease: Power1.easeOut});

        $(".tfive").removeClass("active");
        $(".tsix").addClass("active");

        function outputIt() {
          var newWinners = JSON.parse(localStorage.getItem('winners'));
          var outputs = "";
          for(var i = 0; i < newWinners.queue.length; i++)
          {
          	outputs += '<div id="'+newWinners.queue[i].id + '">' + newWinners.queue[i].id+':'+newWinners.queue[i].name + '</div>';
          }
          document.getElementById("#winners").innerHTML= outputs;
        }

        function pushIt() {
          var newWinners = JSON.parse(localStorage.getItem('winners'));
          var idfind;
          var i = newWinners.queue.length;

            if (newWinners.queue[i].id == null) {
              idfind = 1;
            }
            else{
              idfind = newWinners.queue[newWinners.queue.length].id + 1;
            }


          newWinners.queue.push({
            id:  idfind ,
            name: $('#ans5').val()
          });
          localStorage.setItem('winners', JSON.stringify(newWinners));
          outputIt();
        });
        pushIt();

      }

      break;

    default:

  }


}
